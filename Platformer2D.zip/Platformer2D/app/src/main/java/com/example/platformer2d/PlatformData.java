package com.example.platformer2d;
public class PlatformData {
    public float x;
    public float y;
    public float width;
    public float height;
    public int color;

    public PlatformData(float x, float y, float width, float height, int color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.color = color;
    }
}