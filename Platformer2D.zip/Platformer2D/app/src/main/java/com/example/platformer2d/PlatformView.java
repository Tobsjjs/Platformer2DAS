package com.example.platformer2d;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Nullable;

public class PlatformView extends View {
    private final Paint paint = new Paint();
    private float platformWidth, platformHeight;

    public PlatformView(Context context) {
        super(context);
        init(null);
    }

    public PlatformView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(attrs);
    }

    private void init(AttributeSet attrs) {
        if (attrs != null) {
            TypedArray a = getContext().obtainStyledAttributes(
                    attrs,
                    R.styleable.PlatformView
            );

            paint.setColor(a.getColor(
                    R.styleable.PlatformView_platformColor,
                    0xFF8B4513
            ));

            platformWidth = a.getDimension(
                    R.styleable.PlatformView_platformWidth,
                    100f
            );

            platformHeight = a.getDimension(
                    R.styleable.PlatformView_platformHeight,
                    20f
            );

            a.recycle();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Рисуем платформу в координатах View
        canvas.drawRect(0, 0, platformWidth, platformHeight, paint);
    }

    public Platform createPlatform() {
        // Получаем абсолютные координаты на экране
        int[] location = new int[2];
        getLocationOnScreen(location);

        return new Platform(
                location[0],
                location[1],
                platformWidth,
                platformHeight,
                paint.getColor()
        );
    }
}