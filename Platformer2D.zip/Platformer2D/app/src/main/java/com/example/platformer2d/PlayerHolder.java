package com.example.platformer2d;

public class PlayerHolder {
    private static Player player;

    public static void setPlayer(Player player) {
        PlayerHolder.player = player;
    }

    public static Player getPlayer() {
        return player;
    }
}