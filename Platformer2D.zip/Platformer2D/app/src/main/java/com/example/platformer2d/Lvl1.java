package com.example.platformer2d;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Lvl1 extends AppCompatActivity {
    private GameView gameView;
    private Player player; // Добавляем поле для игрока

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lvl1);

        gameView = findViewById(R.id.gameView);
        player = new Player(100, 800, 50, 80); // Создаем игрока
        gameView.setPlayer(player); // Устанавливаем игрока

        LevelLoader.loadLevel(gameView, R.array.level1_platforms);

        setupControls();
    }

    private void setupControls() {
        Button btnLeft = findViewById(R.id.btnLeft);
        Button btnRight = findViewById(R.id.btnRight);
        Button btnJump = findViewById(R.id.btnJump);

        btnLeft.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                player.move(-1); // Используем поле player напрямую
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                player.move(0);
            }
            return true;
        });

        btnRight.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                player.move(1);
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                player.move(0);
            }
            return true;
        });

        btnJump.setOnClickListener(v -> {
            player.jump();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (gameView != null) {
            gameView.surfaceDestroyed(gameView.getHolder());
        }
    }
    public void to_Main(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}