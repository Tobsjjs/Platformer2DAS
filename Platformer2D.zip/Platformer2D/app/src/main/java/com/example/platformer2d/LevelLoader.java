package com.example.platformer2d;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;

public class LevelLoader {
    public static void loadLevel(GameView gameView, int levelResId) {
        Resources res = gameView.getContext().getResources();
        TypedArray platforms = res.obtainTypedArray(levelResId);

        try {
            for (int i = 0; i < platforms.length(); i++) {
                String[] parts = platforms.getString(i).split(",");
                PlatformData data = new PlatformData(
                        Float.parseFloat(parts[0]),  // x
                        Float.parseFloat(parts[1]),  // y
                        Float.parseFloat(parts[2]),  // width
                        Float.parseFloat(parts[3]),  // height
                        (int) Long.parseLong(parts[4], 16) // color
                );
                gameView.addPlatform(data);
            }
        } finally {
            platforms.recycle();
        }
    }
}