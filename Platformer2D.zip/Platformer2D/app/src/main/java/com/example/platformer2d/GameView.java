package com.example.platformer2d;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {
    private GameThread gameThread;
    private Player player;
    private final List<Platform> platforms = new ArrayList<>();
    private final Paint debugPaint = new Paint();
    private static final String TAG = "GameView";

    public void addPlatform(PlatformData data) {
        platforms.add(new Platform(data.x, data.y, data.width, data.height, data.color));
    }

    public GameView(Context context, Player player) {
        super(context);
        init(player);
    }

    public GameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(null);
    }

    private void init(Player player) {
        getHolder().addCallback(this);
        setZOrderOnTop(false);

        this.player = player != null ? player : new Player(100, 800, 50, 80);
        this.player.setPlatforms(platforms);

        debugPaint.setColor(Color.RED);
        debugPaint.setTextSize(40);

        // Инициализация тестовых платформ
        platforms.add(new Platform(0, 820, 2000, 50, 763)); // Земля
        platforms.add(new Platform(100, 600, 200, 30, 763));
        platforms.add(new Platform(400, 500, 150, 30, 763));
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        gameThread = new GameThread(holder, this);
        gameThread.setRunning(true);
        gameThread.start();
        Log.d(TAG, "Game thread started");
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        Log.d(TAG, "Surface size changed: " + width + "x" + height);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        try {
            gameThread.setRunning(false);
            gameThread.join();
        } catch (InterruptedException e) {
            Log.e(TAG, "Error stopping thread", e);
        }
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        canvas.drawColor(Color.MAGENTA);

        // Рисуем платформы
        for (Platform platform : platforms) {
            platform.draw(canvas);
        }

        // Рисуем игрока
        if (player != null) {
            player.draw(canvas);
        }

        // Отладочная информация
        canvas.drawText("Platforms: " + platforms.size(), 20, 40, debugPaint);
    }

    public void update() {
        if (player != null) {
            player.update();
        }
    }

    public void setPlayer(Player player) {
        this.player = player;
        if (player != null) {
            player.setPlatforms(platforms);
        }
    }
    public Player getPlayer() {
        return player;
    }
}