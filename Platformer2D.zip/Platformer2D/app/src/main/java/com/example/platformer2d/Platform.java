package com.example.platformer2d;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

public class Platform {
    private final float x, y, width, height;
    private final Paint paint;

    public Platform(float x, float y, float width, float height, int color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.paint = new Paint();
        paint.setColor(color);
    }

    public void draw(Canvas canvas) {
        canvas.drawRect(x, y, x + width, y + height, paint);
    }

    public RectF getRect() {
        return new RectF(x, y, x + width, y + height);
    }
}