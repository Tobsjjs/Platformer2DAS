package com.example.platformer2d;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import java.util.List;

public class Player {
    private static final float GRAVITY = 0.8f;
    private static final float JUMP_FORCE = -18f;

    private float x, y;
    private final float width, height;
    private float velocityX, velocityY;
    private boolean onGround;
    private final Paint paint;
    private List<Platform> platforms;

    public Player(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.paint = new Paint();
        paint.setColor(Color.GREEN);
    }

    public void update() {
        // Гравитация
        if (!onGround) {
            velocityY += GRAVITY;
        }

        // Движение
        x += velocityX;
        y += velocityY;

        // Проверка коллизий
        checkCollisions();
    }

    private void checkCollisions() {
        if (platforms == null) return;

        RectF playerRect = getRect();
        onGround = false;

        for (Platform platform : platforms) {
            if (RectF.intersects(playerRect, platform.getRect())) {
                if (velocityY > 0 && playerRect.bottom > platform.getRect().top) {
                    y = platform.getRect().top - height;
                    velocityY = 0;
                    onGround = true;
                }
            }
        }
    }

    public void jump() {
        if (onGround) {
            velocityY = JUMP_FORCE;
            onGround = false;
        }
    }

    public void move(float direction) {
        velocityX = direction * 5;
    }

    public void draw(Canvas canvas) {
        canvas.drawRect(x, y, x + width, y + height, paint);
    }

    public RectF getRect() {
        return new RectF(x, y, x + width, y + height);
    }

    public void setPlatforms(List<Platform> platforms) {
        this.platforms = platforms;
    }
}